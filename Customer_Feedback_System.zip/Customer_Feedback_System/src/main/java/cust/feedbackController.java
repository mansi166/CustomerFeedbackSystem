package cust;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class feedbackController {
	
	@RequestMapping("/")
	public String main() {	
		return "feedbackForm";
	}
	
	@RequestMapping(value="/feedback" , method = RequestMethod.POST)
	public ModelAndView show(
						@RequestParam ("custname") String custname,
						@RequestParam ("email") String email,
						@RequestParam ("product") String product,
						@RequestParam ("rating") int rating,
						@RequestParam ("feedback") String feedback) {
		
		ModelAndView m = new ModelAndView("feedbackForm");
		
		m.addObject("custname", custname);
		m.addObject("email", email);
		m.addObject("product", product);
		m.addObject("rating", rating);
		m.addObject("feedback", feedback);
		return m;
		
	}

}
